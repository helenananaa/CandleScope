#!/bin/sh
exec /usr/bin/sandbox-exec -f '/Users/ryanliang/.codex/worktrees/history-study-navigation-links-20261102/CandleScope/output/history-study-navigation-native-20261102/loopback-only.sb' '/Users/ryanliang/.codex/worktrees/history-study-navigation-links-20261102/CandleScope/output/history-study-navigation-native-20261102/Installed App/CandleScope.app/Contents/MacOS/CandleScope' "$@"
