from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

root=Path.cwd()
out=Path(__file__).parent
sys.path.insert(0,str(root/'docs/qa/indicator-domain-native-20261106'))
from app_copy import clone_app
prior=Path(sys.argv[1])
native=out/sys.argv[2]
manifest=json.loads((prior/'source-package-manifest.json').read_text())
original=Path(manifest['app']).resolve(strict=True)
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
updated=subprocess.check_output(['git','diff','--name-only',manifest['sourceCommit'],source,'--','backend/app','frontend','packages'],text=True).splitlines()
assert updated and all(name.startswith('backend/app/') for name in updated),updated
def sha(path):
    with path.open('rb') as reader:
        return hashlib.file_digest(reader,'sha256').hexdigest()
for name, expected in manifest['files'].items():
    if name not in updated:
        assert sha(root/name)==expected,name
subprocess.run(['codesign','--verify','--deep','--strict',str(original)],check=True)
app=native/'Installed App/CandleScope.app'
clone_app(original,app)
resources=app/'Contents/Resources'
for name in updated:
    target=resources/name
    assert not target.is_symlink() and target.resolve()==target
    shutil.copy2(root/name,target)
    manifest['files'][name]=sha(target)
subprocess.run([str(resources/'python-runtime/python/bin/python3.12'),'-m','compileall','-q','-f',
    *(str(resources/name) for name in updated)],check=True)
assert all(sha(resources/name)==digest for name,digest in manifest['plugins'].items())
assert sha(resources/'app.asar')==manifest['asarSha256']
subprocess.run(['codesign','--force','--deep','--sign','-',str(app)],check=True)
subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True)
manifest.update(app=str(app),runtimeSource=str(original),sourceCommit=source,
    assembly=f'Physical clone with {len(updated)} current backend modules; signed with unchanged renderer and plugin bytes.')
(native/'source-package-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
