from pathlib import Path
from contextlib import closing
import json
import sqlite3
import sys

native=Path(sys.argv[1])
accept=json.loads((native/'acceptance.json').read_text())
frames=json.loads((native/'projection-observations.json').read_text())
traffic=json.loads((native/'traffic.json').read_text())
errors=[event for socket in traffic['sockets'] for event in socket.get('events',[])
        if event.get('error')=='INDICATOR_CALCULATION_ORIGIN_REQUIRED']
target=next((row['evidence']['boundaryOpen'] for row in accept['steps']
    if row['name']=='restart-old-time-updates-and-deletions-boundary-target'),None)
owned=[entry for row in accept['steps'] if row['name']=='quit-requested'
    for entry in (row['evidence'].get('owned') or row['evidence'].get('processes') or [])]
boundary=[]
last=None
with closing(sqlite3.connect((native/'profile/data/candlescope.db').as_uri()+'?mode=ro',uri=True)) as db:
    db.row_factory=sqlite3.Row
    for frame in frames:
        if frame['via']!='ws':
            continue
        position=frame['calculation']
        if last is not None and target is not None:
            previous=last['calculation']
            closed=position['closedThrough']
            if target-60<=closed<=target+60 and closed>previous['closedThrough']:
                durable=db.execute(
                    "select open_time, close_time, source, updated_at from klines where symbol='BTCUSDT' and interval='1m' and open_time=?",
                    (closed*1000,)).fetchone()
                final=db.execute(
                    "select event_time, received_at from kline_source_observations where open_time=? and series like '%BTCUSDT%' and source='websocket' and decision='selected' order by id desc limit 1",
                    (closed*1000,)).fetchone()
                boundary.append({
                    'closedOpening':closed,'receiptAtMs':frame['at'],
                    'previous':previous,'current':position,
                    'sameGeneration':previous['domainId']==position['domainId'] and previous['generation']==position['generation'],
                    'canonical':dict(durable) if durable else None,
                    'lastSelectedSourceObservation':dict(final) if final else None,
                })
        last=frame
report={
    'source':accept['sourceCommit'],'passed':accept['passed'],'expectedBoundaryOpen':target,
    'normalExits':sum(row['name']=='full-owned-exit' for row in accept['steps']),
    'restartObservations':next((len(row['evidence']['observations']) for row in accept['steps']
       if row['name']=='restart-old-time-updates-and-deletions'),None),
    'orderedFrames':sum(row['via']=='ws' and row['type']=='indicator.replace_range'
        and row['meta']['outputUpdate'].get('timeOrder')=='ascending' for row in frames),
    'boundaries':boundary,'originErrors':errors,
    'originWarnings':[line for line in (native/'profile/logs/backend-sidecar.log').read_text().splitlines() if 'Chart origin' in line],
    'ownedPidRecords':len(owned)
}
Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ('source','passed','restartObservations','orderedFrames','originErrors','originWarnings')},
      ensure_ascii=False))
