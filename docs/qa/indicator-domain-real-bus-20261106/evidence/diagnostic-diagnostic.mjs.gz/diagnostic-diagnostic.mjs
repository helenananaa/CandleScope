import fs from 'node:fs/promises';
import cp from 'node:child_process';
import assert from 'node:assert/strict';
import * as q from '/Users/ryanliang/.codex/worktrees/chart-strategy-sessions-20261104/CandleScope/docs/qa/indicator-domain-native-20261106/native-driver.mjs';
const root=q.s.root, manifest=JSON.parse(await fs.readFile(root+'/diagnostic-manifest.json','utf8'));
q.s.receipt.scope='Diagnostic only: actual physical app based on265 plus7s shutdown thread dump; LIVE single BTC chart with no Pine attached. Not functional acceptance.';
q.s.receipt.diagnosticOnly=true;q.s.receipt.baseSource=manifest.baseSourceCommit;q.s.receipt.instrumentation=manifest.instrumentation;
q.s.env={...q.s.env,CANDLESCOPE_RUNTIME_MODE:'LIVE',PYTHONUNBUFFERED:'1',PYTHONDONTWRITEBYTECODE:'1'};
let running=false;
async function observe(name){
 await q.checkCircuit();const workspace=await q.inspect();
 const bars=await q.s.page.evaluate(()=>{
  const element=document.querySelector('[data-chart-cell-id="cell-1"]');if(!element)return null;
  let fiber=element[Object.keys(element).find(k=>k.startsWith('__reactFiber$'))];if(!fiber)return null;while(fiber.return)fiber=fiber.return;
  let found=null;function visit(node){if(!node||found)return;const p=node.memoizedProps;if(p?.seriesStore&&p.datasetKey){const rows=p.seriesStore.snapshot();found={dataset:p.datasetKey,count:rows.length,last:rows.at(-1),previous:rows.at(-2)};return;}visit(node.child);visit(node.sibling);}visit(fiber.stateNode.current);return found;
 });
 await q.record(name,{workspace,bars});
}
try{
 await q.assertPublicGate();running=true;await q.record('diagnostic-launch',await q.launch());
 await q.s.page.getByRole('button',{name:'设置',exact:true}).waitFor({timeout:60000});await q.enableControl();
 await q.record('configure-one-chart-no-pine',await q.configure([{session:q.session('BTCUSDT','1m'),indicators:[]}],'single'));
 await q.until(async()=>{await q.checkCircuit();const s=await q.inspect();return s.cells[0]?.runtime.marketReady&&!s.cells[0]?.runtime.loading?s:false;},90000);
 await observe('no-pine-input-0');await q.delay(5000);await observe('no-pine-input-5s');await q.delay(5000);await observe('no-pine-input-10s');
}catch(e){q.s.receipt.failure=String(e.stack||e);process.exitCode=1;}
finally{
 if(running&&q.s.app){try{await q.quit();q.s.receipt.allOwnedExited=await q.exited();}catch(e){q.s.receipt.cleanupFailure=String(e.stack||e);process.exitCode=1;}}
 q.s.receipt.completedAt=new Date().toISOString();await q.save();
 const status=await fs.readFile(root+'/sidecar-exit-status.json','utf8').then(JSON.parse).catch(()=>null);console.log(JSON.stringify({diagnosticOnly:true,failure:q.s.receipt.failure,cleanupFailure:q.s.receipt.cleanupFailure,allOwnedExited:q.s.receipt.allOwnedExited,sidecar:status}));
 cp.execFileSync('codesign',['--verify','--deep','--strict',manifest.app]);
}
