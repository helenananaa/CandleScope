import pytest

from app.data_engine.data_manager.models import DataEvent, DataEventType, SeriesKey
from tests import test_chart_calculation_transports as transport
from tests.test_chart_calculation_transports import wire  # noqa: F401
from tests.test_chart_calculation_real_bus import real_bus_wire  # noqa: F401
from tests.test_kline_revision_contract import storage  # noqa: F401

@pytest.mark.parametrize("preview_count", [1, 6])
def test_normal_close_preserves_generation_and_intrabar_trace(real_bus_wire, preview_count):
    wire = real_bus_wire
    initial = wire.client.post('/indicators/calculations', json=transport.open_request()).json()
    with wire.client.websocket_connect('/ws') as ws:
        transport.subscribe(ws, transport.ref(initial))
        assert transport.receive(ws, 'indicator.subscribed')['ok']
        assert transport.value(transport.receive(ws, 'indicator.snapshot')) == 500
        for i in range(preview_count):
            wire.client.post(f'/fixture/tick/501?close={100+i}')
            assert transport.value(transport.receive(ws, 'indicator.replace_range', 'indicator.patch', 'indicator.snapshot')) == 501 + i

        async def close():
            wire.source.rows = list(transport.bars(501))
            await wire.source.emit(DataEvent(DataEventType.BAR_CLOSED,
                SeriesKey('BTCUSDT', '1m'), bar=wire.source.rows[-1]))

        wire.client.portal.call(close)
        output = transport.receive(ws, 'error', 'indicator.replace_range', 'indicator.patch', 'indicator.snapshot')
        assert output['type'] != 'error', output
        assert transport.value(output) == 501 + preview_count
        assert output['calculation']['generation'] == initial['calculation']['generation']
        wire.client.post('/fixture/tick/502?close=101')
        assert transport.value(transport.receive(ws, 'indicator.replace_range', 'indicator.patch', 'indicator.snapshot')) == 502 + preview_count
        ws.send_json({'action': 'unsubscribe', 'clientId': 'chart-a'})
        transport.receive(ws, 'indicator.unsubscribed')
    assert wire.client.delete('/indicators/calculations/' + transport.ref(initial)['domainId']).json()['state'] == 'closed'
