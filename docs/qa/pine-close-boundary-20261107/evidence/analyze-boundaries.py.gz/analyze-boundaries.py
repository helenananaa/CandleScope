"""Join selected Binance final BARs to the actual Pine WebSocket cursor."""
from datetime import datetime
import json
from pathlib import Path
import sqlite3
import sys

root = Path(sys.argv[1]).resolve(strict=True)
read = lambda name: json.loads((root / name).read_text())
receipt = read("acceptance.json")
launches = [step for step in receipt["steps"] if step["name"] == "launch"]
assert len(launches) == 2
restart_ms = int(datetime.fromisoformat(launches[1]["at"]).timestamp() * 1000)
close_ms = int(datetime.fromisoformat(
    [step for step in receipt["steps"] if step["name"] == "quit-requested"][-1]["at"]
).timestamp() * 1000)
frames = sorted(
    (frame for socket in read("traffic.json")["sockets"]
     if "/stream/indicators" in socket["url"]
     for frame in socket.get("events", [])
     if restart_ms <= frame["at"] <= close_ms),
    key=lambda frame: frame["at"],
)
events = [frame for frame in frames if frame.get("calculation") and frame["type"].startswith("indicator.")]
market = root / "profile/data/candlescope.db"
assert not market.with_name("candlescope.db-wal").exists()
with sqlite3.connect(market.as_uri() + "?mode=ro&immutable=1", uri=True) as db:
    rows = db.execute(
        """SELECT open_time,event_time,received_at
             FROM kline_source_observations
             WHERE series=? AND source='websocket' AND decision='selected'
               AND json_extract(envelope_json,'$.closed')=1
               AND received_at BETWEEN ? AND ? ORDER BY open_time,received_at""",
        ('["binance","spot","BTCUSDT","1m"]', restart_ms, close_ms),
    ).fetchall()
report = []
for opened, venue, received in rows:
    boundary = opened + 60000
    previous = next((frame for frame in reversed(events)
                     if frame["at"] <= max(boundary, received)
                     and frame["calculation"]["observedThrough"] == opened // 1000
                     and frame["calculation"]["closedThrough"] < opened // 1000), None)
    after = next((frame for frame in events
                  if frame["at"] >= received
                  and frame["calculation"]["closedThrough"] == opened // 1000), None)
    previous_position = previous and previous["calculation"]
    after_position = after and after["calculation"]
    nearby_errors = [{"at": frame["at"], "error": frame["error"]} for frame in frames
                     if frame["type"] == "error" and abs(frame["at"] - boundary) < 1000]
    report.append({
        "openMs": opened, "venueFinalMs": venue, "receivedMs": received,
        "arrivalRelativeToBoundaryMs": received - boundary,
        "firstCloseProjectionMs": after and after["at"],
        "projectionRelativeToBoundaryMs": after and after["at"] - boundary,
        "before": previous_position, "after": after_position,
        "sameGeneration": bool(previous_position and after_position
                               and previous_position["domainId"] == after_position["domainId"]
                               and previous_position["generation"] == after_position["generation"]),
        "nearbyErrors": nearby_errors,
    })
print(json.dumps({"nativePassed": receipt["passed"], "boundaries": report}, indent=2))
