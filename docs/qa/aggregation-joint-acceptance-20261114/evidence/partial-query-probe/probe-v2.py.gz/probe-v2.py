import asyncio, json, sqlite3, sys
from pathlib import Path
from unittest.mock import patch
root=Path(sys.argv[1]);sys.path.insert(0,str(root/'backend'))
from app.core import config as core_config
from app.data_engine.storage import klines_repo
from app.data_engine.data_manager import DataManager
from app.data_engine.data_manager.config import DataManagerConfig
from app.data_engine.interval_policy import parse_interval_spec
source=root/'output/aggregation-joint-acceptance-20261114/native-candidate/usdm-prime-cold-baseline/profile/data/candlescope.db'
out=root/'output/aggregation-joint-acceptance-20261114/partial-query-probe'
target=out/'source-copy-v2.sqlite';assert not target.exists()
with sqlite3.connect('file:'+str(source)+'?mode=ro',uri=True) as source_conn, sqlite3.connect(target) as destination:
 source_conn.backup(destination)
klines_repo.KLINES_DB_PATH=core_config.KLINES_DB_PATH=target
results=[]
for method in ['query','query_materialized']:
 config=DataManagerConfig();config.query.auto_backfill=False
 manager=DataManager(config);manager.set_storage(klines_repo.KlinesRepoAdapter())
 try:
  spec=parse_interval_spec('89m');end=1794624480000;count=221;start=end-(count-1)*spec.nominal_ms
  floor=manager.query_engine.storage.revision_store.head()
  result=getattr(manager,method)('BTCUSDT','89m',start_ms=start,end_ms=end,limit=count,exchange='binance',market_type='futures',**({'auto_backfill':False,'min_revision':floor} if method=='query' else {}))
  value=dict(method=method,bars=len(result.bars),complete=result.complete,retryable=result.retryable,history_state=result.history_state,metadata=result.metadata,missing=[item.to_dict() for item in result.missing_ranges])
  results.append(value);print(json.dumps(value,default=str),flush=True)
 finally:
  asyncio.run(manager.shutdown())
(out/'results-v2.json').write_text(json.dumps(results,indent=2,default=str)+'\n')
