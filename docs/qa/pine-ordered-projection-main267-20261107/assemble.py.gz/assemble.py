from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile

root = Path.cwd()
out = Path(__file__).parent
sys.path.insert(0, str(root/'docs/qa/indicator-domain-native-20261106'))
from app_copy import clone_app
sys.path.pop(0)

native = out/'native'
prior = out.parent/'pine-main269-origin-reseed-20261107/native/source-package-manifest.json'
manifest = json.loads(prior.read_text())
source = (out/'source.txt').read_text().strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
original = Path(manifest['app']).resolve(strict=True)
app = native/'Installed App/CandleScope.app'
backend = subprocess.check_output(['git','diff','--name-only',manifest['sourceCommit'],source,'--','backend/app','frontend','packages'],text=True).splitlines()
expected = {
    'backend/app/api/v1/stream_indicator_payloads.py',
    'backend/app/indicator/range_projection.py',
    'backend/app/indicator/serialization.py',
    'packages/candlescope-plugin-pine-compat/src/candlescope_plugin_pine_compat/runtime.py',
    'packages/candlescope-plugin-pine-compat/tests/test_output_update_range.py',
}
assert set(backend)==expected, backend
def sha(path):
    with path.open('rb') as reader:
        return hashlib.file_digest(reader,'sha256').hexdigest()

for name, expected_digest in manifest['files'].items():
    if name not in backend:
        assert sha(root/name)==expected_digest, name
subprocess.run(['codesign','--verify','--deep','--strict',str(original)],check=True)
clone_app(original, app)
resources = app/'Contents/Resources'
updated = []
for name in backend:
    if name.startswith('backend/app/'):
        target = resources/name
        assert not target.is_symlink() and target.resolve()==target
        shutil.copy2(root/name,target)
        manifest['files'][name]=sha(target)
        updated.append(target)

script = root/'frontend/scripts/prepare-desktop-plugins.py'
from importlib.util import module_from_spec, spec_from_file_location
spec = spec_from_file_location('prepare_desktop_plugins_qa',script)
prepare = module_from_spec(spec)
spec.loader.exec_module(prepare)
plugins = resources/'python-runtime/plugins'
metadata = json.loads((plugins/'manifest.json').read_text())
entry = next(record for record in metadata['plugins'] if record['runtimeId']=='candlescope.pine-compat')
bundle = plugins/entry['filename']
lock_path = plugins/'candlescope-plugin-pine-compat.lock.json'
lock = json.loads(lock_path.read_text())
bridge = root/'packages/candlescope-plugin-pine-compat'
builder = prepare.module(bridge/'scripts/build_bundle.py','candidate_builder')
canonicalizer = prepare.module(bridge/'scripts/canonicalize_wheel.py','candidate_canonicalizer')
wheels = out/'wheels'
changed = next(wheels.glob('candlescope_plugin_pine_compat-*.whl'))
canonicalizer.canonicalize(changed)
assert 'sha256:'+sha(bundle)==entry['sha256']
with zipfile.ZipFile(bundle) as old_bundle:
    for key, record in lock['wheels'].items():
        if key=='candlescope-plugin-pine-compat':
            continue
        old_file = wheels/record['artifactFilename']
        old_file.write_bytes(old_bundle.read('wheels/'+old_file.name))
        assert 'sha256:'+sha(old_file)==record['sha256']
record = builder.inspect_wheel(changed)
lock['wheels']['candlescope-plugin-pine-compat']={
    'version':record.version,'artifactFilename':record.path.name,
    'sha256':record.sha256,'size':record.path.stat().st_size,
}
lock['bridgeSourceSha256'] = prepare.source_digest(bridge)
assert lock['sdkSourceSha256']==prepare.source_digest(root/'packages/candlescope-plugin-sdk')
lock_path.write_text(json.dumps(lock,indent=2)+'\n')
next_bundle = out/bundle.name
result = builder.build_locked_bundle([wheels/record['artifactFilename'] for record in lock['wheels'].values()],
    next_bundle, lock_path=lock_path)
shutil.copy2(next_bundle,bundle)
entry.update(sha256=result.sha256,size=result.size)
(plugins/'manifest.json').write_text(json.dumps(metadata,indent=2)+'\n')
for path in (bundle,lock_path,plugins/'manifest.json'):
    manifest['plugins'][str(path.relative_to(resources))] = sha(path)
assert all(sha(resources/name)==expected_digest for name,expected_digest in manifest['plugins'].items())
assert sha(resources/'app.asar')==manifest['asarSha256']
subprocess.run([str(resources/'python-runtime/python/bin/python3.12'),'-m','compileall','-q','-f',*map(str,updated)],check=True)
subprocess.run(['codesign','--force','--deep','--sign','-',str(app)],check=True)
subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True)
manifest.update(app=str(app), runtimeSource=str(original), sourceCommit=source, assembly=(
    'Clone prior candidate. Overlay three backend modules and rebuild the Pine bridge wheel from current source. '
    'Engine and SDK wheels are byte-identical to the verified original bundle. Renderer ASAR retained by hash.'))
(native/'source-package-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
