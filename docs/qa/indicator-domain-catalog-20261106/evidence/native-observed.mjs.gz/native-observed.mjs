import fs from 'node:fs/promises';
import * as q from 'file:///Users/ryanliang/.codex/worktrees/chart-strategy-sessions-20261104/CandleScope/docs/qa/indicator-domain-native-20261106/native-driver.mjs';
q.s.env={...q.s.env,CANDLESCOPE_RUNTIME_MODE:'LIVE',PYTHONUNBUFFERED:'1',PYTHONDONTWRITEBYTECODE:'1'};
let stop=false;
const sampler=(async()=>{
 while(!stop&&!q.s.page)await q.delay(50);
 if(stop)return;
 q.s.page.on('websocket',ws=>{
  if(!ws.url().includes('/stream/klines'))return;
  let count=0;
  ws.on('framereceived',event=>{
   if(count++>=500)return;
   fs.appendFile(q.s.root+'/observed-kline-frames.ndjson',JSON.stringify({at:Date.now(),url:ws.url(),payload:String(event.payload)})+'\n').catch(()=>{});
  });
 });
 while(!stop){
  try{
   const response=await fetch(q.s.backend+'/debug/snapshot',{signal:AbortSignal.timeout(5000)});
   const value=await response.json();
   const selected=Object.fromEntries(['started','coordinator','stream_leases','bar_aggregator','bar_delivery','event_bus','price_cache','replay'].map(k=>[k,value[k]]));
   await fs.appendFile(q.s.root+'/observed-source-snapshots.ndjson',JSON.stringify({at:Date.now(),status:response.status,...selected})+'\n');
  }catch(error){await fs.appendFile(q.s.root+'/observer-errors.ndjson',JSON.stringify({at:Date.now(),error:String(error)})+'\n').catch(()=>{});}
  for(let i=0;i<100&&!stop;i++)await q.delay(100);
 }
})();
try{await import('file:///Users/ryanliang/.codex/worktrees/chart-strategy-sessions-20261104/CandleScope/docs/qa/indicator-domain-native-20261106/native-acceptance.mjs');}
finally{stop=true;await sampler;}
