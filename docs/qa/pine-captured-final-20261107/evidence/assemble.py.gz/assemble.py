import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path.cwd(); out=Path(__file__).parent; b=out.parent; native=out/'native'
sys.path.insert(0,str(root/'docs/qa/indicator-domain-native-20261106'))
from app_copy import clone_app
previous=b/'pine-close-origin-20261107/fixed/source-package-manifest.json'
m=json.loads(previous.read_text()); original=Path(m['app']).resolve(strict=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
changed=subprocess.check_output(['git','diff','--name-only',m['sourceCommit'],commit,'--','backend/app','packages','frontend'],text=True).splitlines()
assert changed==['backend/app/api/v1/chart_calculation_stream.py'],changed
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
for name,h in m['files'].items():
    if name not in changed: assert sha(root/name)==h,name
subprocess.run(['codesign','--verify','--deep','--strict',str(original)],check=True)
app=native/'Installed App/CandleScope.app'; clone_app(original,app)
resources=app/'Contents/Resources'
for name in changed:
    target=resources/name; assert not target.is_symlink() and target.resolve()==target
    shutil.copy2(root/name,target);m['files'][name]=sha(target)
subprocess.run([str(resources/'python-runtime/python/bin/python3.12'),'-m','compileall','-q','-f',*[str(resources/name) for name in changed]],check=True)
subprocess.run(['codesign','--force','--deep','--sign','-',str(app)],check=True)
assert sha(resources/'app.asar')==m['asarSha256']
m.update(app=str(app),runtimeSource=str(original),sourceCommit=commit,assembly='physical clone of verified source-rebuild app; one chart stream module overlaid and compiled; same frontend/runtime/plugins')
(native/'source-package-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
