from pathlib import Path
import subprocess,os,json
b=Path(__file__).parent;n=b/'native';n.mkdir(exist_ok=False)
r=Path('/Users/ryanliang/.codex/worktrees/chart-strategy-sessions-20261104/CandleScope')
e={**os.environ,'CANDLESCOPE_BATCH1_QA_ROOT':str(n),'CANDLESCOPE_QA_REUSE_VERIFIED_PLUGINS':'1','CANDLESCOPE_QA_RUNTIME_SOURCE':'/Users/ryanliang/CandleScope/output/development-goal-20261104/oi-main266-native-20261106/native/Installed App/CandleScope.app','PYTHONDONTWRITEBYTECODE':'1'}
with (b/'assembly.log').open('w') as log:
 result=subprocess.run(['python3','-B','docs/qa/alerts-main266-native-20261106/assemble.py'],cwd=r,env=e,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0,'Inspect assembly.log; preserve failed candidate'
with (b/'preflight-verification.log').open('w') as log:
 result=subprocess.run(['node','docs/qa/alerts-main266-native-20261106/verify.mjs'],cwd=r,env=e,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0,'Inspect preflight-verification.log'
(n/'verified-before.json').write_bytes((n/'verified-after.json').read_bytes())
print(json.dumps({'assemblyExit':0,'verifyExit':0,'app':str(n/'Installed App/CandleScope.app')}))
