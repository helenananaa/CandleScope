from pathlib import Path
import json,os,subprocess,datetime
p=Path(__file__).parent/'checks.json';d=json.loads(p.read_text());d['started']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(d,indent=2)+'\n')
with (p.parent/'backend-combined.log').open('w') as log:
 r=subprocess.run(d['command'],env={**os.environ,**d['env']},stdout=log,stderr=subprocess.STDOUT)
d['exitCode']=r.returncode;d['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'exitCode':r.returncode,'suites':d['suites']}));raise SystemExit(r.returncode)
