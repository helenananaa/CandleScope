import hashlib
import json
import os
import shutil
import socket
import subprocess
import sys
from pathlib import Path

root = Path(__file__).parent
base = root.parent
original = base / 'continuous-native-main267-20261107/native-seeded'
run = root / sys.argv[1]
assert run.name in {'paused', 'resumed', 'resumed-retry'}
receipt = json.loads((original / 'acceptance.json').read_text())
assert receipt['passed']
result = next(step['evidence']['after'] for step in receipt['steps'] if step['name'] == 'cold-account-after-restart')
source_profile = original / 'profile'
for pattern in ('**/*-wal', '**/*-journal'):
    assert all(not f.stat().st_size for f in source_profile.glob(pattern))
candidate = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else original
manifest = json.loads((candidate / 'source-package-manifest.json').read_text())
app = Path(manifest['app']).resolve(strict=True)
subprocess.run(['git','diff','--exit-code',manifest['sourceCommit'],'HEAD','--','backend','frontend','packages'],check=True)
subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True)
def fingerprints():
    return {str(p.relative_to(source_profile)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in source_profile.rglob('*') if p.is_file()}
before = fingerprints()
run.mkdir()
profile = run / 'profile'
# The source fixture has no prepared-input chunks. Its directory only holds
# a path-bound owner marker and lock. Let the copied DB adopt a fresh cache.
cache = source_profile / 'data/prepared-inputs'
assert {p.name for p in cache.iterdir()} <= {'.preparation-owner', '.preparation-owner.lock'}
def omit_reproducible_state(directory, names):
    root = Path(directory)
    if root == source_profile / 'data':
        return {'prepared-inputs'}
    if root == source_profile:
        return {'logs'}
    return set()
shutil.copytree(source_profile, profile, ignore=omit_reproducible_state)
# Rebind only the QA copy, after confirming that the private-input marker
# and database came from the verified stopped source profile.
relative_db = Path('data/continuous-strategy.sqlite3')
marker_path = Path('data/continuous-strategy-inputs/owner.json')
source_owner = json.loads((source_profile/marker_path).read_text())
assert source_owner == {'schema':'candlescope.continuous-private-inputs/1',
                        'database':str((source_profile/relative_db).resolve(strict=True))}
assert hashlib.sha256((profile/relative_db).read_bytes()).hexdigest() == before[str(relative_db)]
cloned_marker = profile/marker_path
assert not cloned_marker.is_symlink() and cloned_marker.resolve() == cloned_marker
assert json.loads(cloned_marker.read_text()) == source_owner
cloned_owner = {**source_owner, 'database':str((profile/relative_db).resolve(strict=True))}
cloned_marker.write_text(json.dumps(cloned_owner,indent=2)+'\n')
(run/'input-owner-copy-rebind.json').write_text(json.dumps({'before':source_owner,'after':cloned_owner},indent=2)+'\n')
seed = json.loads((original / 'research-seed.json').read_text())
data = {'omittedCopiedPaths':['data/prepared-inputs (only owner marker and lock)','logs'], 'original':str(original),'account':result,'researchId':seed['runId'],
        'researchProfile':str(base/'continuous-live-main268-20261107/seed-imported-bars/profile')}
(run/'controlled-repair-copy.json').write_text(json.dumps(data,indent=2)+'\n')
(run/'source-package-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(run/'Installed App').mkdir()
(run/'Installed App/CandleScope.app').symlink_to(app,target_is_directory=True)
resources = app/'Contents/Resources'
amend_env = {**os.environ,'PYTHONDONTWRITEBYTECODE':'1','DATA_DIR':str(profile/'data'),
             'CANDLE_DATA_DIR':str(profile/'data'),'KLINES_DB_PATH':str(profile/'data/market.db'),
             'PYTHONPATH':f'{resources}/backend:{resources}/python-runtime/site-packages'}
with (run/'controlled-revision.json').open('w') as out, (run/'seed.log').open('w') as err:
    subprocess.run([str(resources/'python-runtime/python/bin/python3.12'),'-B',
                    'docs/qa/continuous-native-repair-20261107/amend_market.py',str(profile)],
                   env=amend_env,stdout=out,stderr=err,check=True)
port = int(json.loads((original/'launch-env.json').read_text())['CANDLESCOPE_QA_UI_PORT'])
with socket.socket() as check:
    check.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    check.bind(('127.0.0.1',port))
env = {'CANDLESCOPE_BATCH1_QA_ROOT':str(run),'CANDLESCOPE_QA_UI_PORT':str(port),
       'CANDLESCOPE_PLAYWRIGHT_PACKAGE':str(base/'native-tooling-20261106/package.json')}
(run/'launch-env.json').write_text(json.dumps(env,indent=2)+'\n')
with (run/'native.log').open('w') as out:
    (run / 'home').mkdir()
    script = """
import * as q from './docs/qa/continuous-live-main268-20261107/native-driver.mjs';
q.s.env = {...q.s.env, HOME: q.s.root + '/home', LOCALAPPDATA: q.s.root + '/home'};
await import('./docs/qa/continuous-native-repair-20261107/native.mjs');
"""
    code = subprocess.run(['node','--input-type=module','-e',script],
                          env={**os.environ,**env},stdout=out,stderr=subprocess.STDOUT).returncode
assert before == fingerprints()
subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True)
(run/'protection.json').write_text(json.dumps({'sourceProfile':str(source_profile),
    'allOriginalFilesUnchanged':True,'originalFingerprints':before,'candidateSignatureValid':True,'exitCode':code},indent=2)+'\n')
print((run/'native.log').read_text()[-2000:])
raise SystemExit(code)
