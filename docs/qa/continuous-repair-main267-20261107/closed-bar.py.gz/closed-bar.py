from contextlib import closing
from pathlib import Path
import json
import sqlite3
import sys

root=Path(sys.argv[1])
receipt=json.loads((root/'acceptance.json').read_text())
before=next(row['evidence'] for row in receipt['steps'] if row['name']=='cold-repaired-before-restart')
after=next(row['evidence']['second'] for row in receipt['steps'] if row['name']=='cold-repaired-after-restart')
assert receipt['passed'] and receipt['resumeAfter'] and after['sequence']>before['sequence']
market=root/'profile/data/market.db'
assert not market.with_name('market.db-wal').exists()
witnesses=[]
with closing(sqlite3.connect(market.as_uri()+'?mode=ro&immutable=1',uri=True)) as connection:
    for close_ms in range(before['eventTimeMs']+60000,after['eventTimeMs']+1,60000):
        open_ms=close_ms-59999
        rows=connection.execute(
            "select envelope_json,received_at,decision from kline_source_observations "
            "where open_time=? and series like '%BTCUSDT%' and source='websocket' and decision='selected' order by id desc",
            (open_ms,))
        for raw,received,decision in rows:
            envelope=json.loads(raw)
            event=json.loads(envelope['raw'])
            k=event.get('k',{})
            if k.get('x') is True and k.get('t')==open_ms and k.get('T')==close_ms and k.get('i')=='1m':
                durable=connection.execute(
                    "select open_time,close_time,close,source from klines where symbol='BTCUSDT' and interval='1m' and market_type='spot' and open_time=?",
                    (open_ms,)).fetchone()
                assert durable and durable[0]==open_ms and durable[1]==close_ms
                assert durable[2]==float(k['c']) and durable[3]=='source_snapshot_verified'
                witnesses.append({'envelope':envelope,'receivedAtMs':received,'decision':decision,'durableRow':durable})
                break
        else:
            raise AssertionError(f'missing selected live close for {close_ms}')
assert len(witnesses)==after['sequence']-before['sequence']
print(json.dumps(witnesses,indent=2))
