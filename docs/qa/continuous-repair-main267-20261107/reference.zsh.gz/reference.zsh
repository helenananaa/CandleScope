set -e
out=${0:h}
label="$1"
scratch="$PWD/output/current-repair-reference/$label"
mkdir -p "$scratch"
case "$label" in paused|resumed-retry);; *) exit 1;; esac
profile="$out/$label/profile/data"
test ! -s "$profile/market.db-wal"
cp "$profile/market.db" "$scratch/market.db"
app=$(jq -r .app "$out/$label/source-package-manifest.json")
resources="$app/Contents/Resources"
env PYTHONDONTWRITEBYTECODE=1 DATA_DIR="$scratch" CANDLE_DATA_DIR="$scratch" KLINES_DB_PATH="$scratch/market.db" PYTHONPATH="$resources/backend:$resources/python-runtime/site-packages" "$resources/python-runtime/python/bin/python3.12" -B docs/qa/continuous-native-repair-20261107/reference.py "$profile/continuous-strategy.sqlite3" "$scratch" > "$out/$label/reference.json" 2> "$out/$label/reference.log"
cat "$out/$label/reference.json"
