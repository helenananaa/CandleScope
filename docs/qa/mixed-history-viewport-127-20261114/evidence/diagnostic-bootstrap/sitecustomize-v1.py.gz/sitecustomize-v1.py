"""Diagnostic-only task stacks; no values, network calls or execution changes."""
import asyncio
import datetime
import json
import os
from pathlib import Path

original = asyncio.BaseEventLoop.run_forever
output = Path(__file__).resolve().parent.parent / f'diagnostic-tasks-{os.getpid()}.jsonl'

def dump(loop):
    rows = []
    for task in asyncio.all_tasks(loop):
        chain = []
        current = task.get_coro()
        for _ in range(40):
            frame = getattr(current, 'cr_frame', None) or getattr(current, 'gi_frame', None)
            if frame is not None:
                chain.append(dict(file=frame.f_code.co_filename, line=frame.f_lineno,
                                  function=frame.f_code.co_name))
            current = getattr(current, 'cr_await', None) or getattr(current, 'gi_yieldfrom', None)
            if current is None:
                break
        rows.append(dict(name=task.get_name(), chain=chain))
    with output.open('a') as stream:
        stream.write(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(), tasks=rows))+'\n')
    loop.call_later(20, dump, loop)

def run(loop):
    if not getattr(loop, '_qa_task_dump', False):
        loop._qa_task_dump = True
        loop.call_later(20, dump, loop)
    return original(loop)

asyncio.BaseEventLoop.run_forever = run

