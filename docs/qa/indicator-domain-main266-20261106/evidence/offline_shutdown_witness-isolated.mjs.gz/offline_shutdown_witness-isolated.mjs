import fs from 'node:fs';
import cp from 'node:child_process';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const base='/Users/ryanliang/CandleScope/output/development-goal-20261104';
const root=base+'/indicator-domain-main266-native-20261106/offline-shutdown-witness-isolated';
assert.ok(!fs.existsSync(root));fs.mkdirSync(root,{recursive:true});
const candidate=base+'/indicator-domain-main266-native-20261106';
const manifest=JSON.parse(fs.readFileSync(candidate+'/source-package-manifest.json','utf8'));
const {_electron}=createRequire(base+'/native-tooling-20261106/package.json')('playwright-core');
const env={...process.env,CANDLESCOPE_RUNTIME_MODE:'LOCAL_OFFLINE',PYTHONDONTWRITEBYTECODE:'1',
 CANDLESCOPE_DESKTOP_USER_DATA:root+'/profile',CANDLE_DATA_DIR:root+'/profile/data',
 KLINES_DB_PATH:root+'/profile/data/market.db',BACKTEST_DB_PATH:root+'/profile/data/backtest.db',REPLAY_DB_PATH:root+'/profile/data/replay.db',
 CANDLESCOPE_PLUGIN_PLATFORM_V2_ROOT:root+'/profile/plugins',CANDLESCOPE_LOCAL_DATA_DIR:root+'/profile/local-data',
 CANDLESCOPE_DESKTOP_UI_PORT:'0',CANDLESCOPE_DESKTOP_BACKEND_PORT:'0'};
for(const k of ['ELECTRON_RUN_AS_NODE','PYTHONPATH','CANDLESCOPE_DESKTOP_URL','CANDLESCOPE_DESKTOP_SKIP_SIDECAR','CANDLESCOPE_DESKTOP_SIDECAR_COMMAND_JSON','CANDLESCOPE_PYTHON'])delete env[k];
const rows=()=>cp.execFileSync('ps',['-axo','pid=,ppid=,command='],{encoding:'utf8'}).trim().split('\n').map(s=>{const m=s.trim().match(/^(\d+)\s+(\d+)\s+(.*)$/);return {pid:+m[1],ppid:+m[2],command:m[3]};});
const result={source:manifest.sourceCommit,scope:'Actual packaged LOCAL_OFFLINE startup and observational owned-sidecar exit code/signal. No live feeds or script execution qualification.',errors:[],requests:[]};let app;
try{
 app=await _electron.launch({executablePath:manifest.app+'/Contents/MacOS/CandleScope',env,timeout:45000});
 const page=await app.firstWindow({timeout:45000});
 page.on('pageerror',e=>result.errors.push(String(e.stack||e)));
 page.on('request',r=>{const u=new URL(r.url());if(['http:','https:','ws:','wss:'].includes(u.protocol))result.requests.push(u.href);});
 await page.waitForURL(u=>u.protocol==='http:'&&u.hostname==='127.0.0.1',{timeout:45000,waitUntil:'load'});
 const bootstrap=await page.evaluate(()=>window.candlescopeDesktop.getBootstrap());
 const health=await(await fetch(bootstrap.sidecar.healthUrl)).json();assert.equal(health.runtime_mode,'LOCAL_OFFLINE');assert.equal(health.local_offline.network.installed,true);assert.equal(health.local_offline.network.blocked_attempts,0);result.health=health;
 result.identity=await app.evaluate(({app})=>({packaged:app.isPackaged,pid:process.pid,profile:app.getPath('userData'),resources:process.resourcesPath}));
 assert.equal(result.identity.packaged,true);assert.equal(result.identity.profile,root+'/profile');assert.equal(result.identity.resources,fs.realpathSync(manifest.app)+'/Contents/Resources','Must execute the intended physical app resources');
 result.observer=await app.evaluate(async(_electron,path)=>{
  const fs=process.getBuiltinModule('fs');
  const children=process._getActiveHandles().filter(h=>h.constructor?.name==='ChildProcess'&&h.pid&&String(h.spawnfile).includes(process.resourcesPath));
  const found=children.map(h=>({pid:h.pid,spawnfile:h.spawnfile}));
  fs.writeFileSync(path,JSON.stringify({observedChildren:found,exits:[]},null,2));
  for(const h of children)h.once('exit',(code,signal)=>{const state=JSON.parse(fs.readFileSync(path,'utf8'));state.exits.push({pid:h.pid,code,signal,at:new Date().toISOString()});fs.writeFileSync(path,JSON.stringify(state,null,2));});
  return found;
 },root+'/sidecar-exit-status.json');
 assert.equal(result.observer.length,1,'Must observe exactly actual packaged sidecar ChildProcess');
 const processes=rows(),owned=new Set([result.identity.pid]);let changed=true;
 while(changed){changed=false;for(const p of processes)if(owned.has(p.ppid)&&!owned.has(p.pid)){owned.add(p.pid);changed=true;}}
 result.owned=processes.filter(p=>owned.has(p.pid));
 const start=Date.now();await app.close();app=null;result.closeElapsedMs=Date.now()-start;
 const deadline=Date.now()+10000;while(rows().some(p=>owned.has(p.pid))&&Date.now()<deadline)await new Promise(r=>setTimeout(r,100));
 result.remaining=rows().filter(p=>owned.has(p.pid));result.exitStatus=JSON.parse(fs.readFileSync(root+'/sidecar-exit-status.json','utf8'));
 assert.deepEqual(result.remaining,[]);assert.equal(result.exitStatus.exits.length,1);assert.equal(result.exitStatus.exits[0].code,0);assert.equal(result.exitStatus.exits[0].signal,null);assert.deepEqual(result.errors,[]);assert.deepEqual(result.requests.filter(u=>new URL(u).hostname!=='127.0.0.1'),[]);
 result.passed=true;
}catch(e){result.failure=String(e.stack||e);process.exitCode=1;}
finally{if(app)await app.close().catch(e=>result.cleanupFailure=String(e));fs.writeFileSync(root+'/receipt.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({passed:result.passed??false,failure:result.failure,closeElapsedMs:result.closeElapsedMs,exitStatus:result.exitStatus,remaining:result.remaining}));}
