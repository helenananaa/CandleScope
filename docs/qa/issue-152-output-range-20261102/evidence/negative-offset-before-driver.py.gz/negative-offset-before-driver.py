import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[3]
SITE=Path('/Users/ryanliang/.codex/retained-worktree-resources/CandleScope/h127-r129-adoption-20261101-39b9de42/output/h127-r129-native-20261101/attempts/attempt9/profile/data/plugins/installs/candlescope.pine-compat/c99fa34216a8e7f90e2953891bf306872e94b3edfd4fe1103159e12619cae3b7/venv/lib/python3.12/site-packages')
sys.path[:0]=[str(ROOT/'backend'),str(ROOT/'packages/candlescope-plugin-sdk/src'),str(ROOT/'packages/candlescope-plugin-pine-compat/src'),str(SITE)]
from candlescope_plugin_pine_compat import PineCompatRuntimePlugin
from candlescope_plugin_sdk import Bar, ExecuteBatchRequest, MarketContext
from app.api.v1.stream_indicator_payloads import _plugin_snapshot_or_patch_from_result
source='//@version=6\nindicator("negative offset")\nplot(close,offset=-1)'
plugin=PineCompatRuntimePlugin()
history=tuple(Bar(time=1700000000+i*60,open=100,high=105,low=99,close=101,volume=1,is_closed=True) for i in range(20))
meta={'exchange':'binance','market_type':'spot','symbol':'BTCUSDT','interval':'1m','name':'negative offset','language':'pine','params':{},'indicatorId':'negative-offset'}
rows=[]
try:
 for close in (102,103):
  bars=history+(Bar(time=1700000000+20*60,open=101,high=105,low=99,close=close,volume=2,is_closed=False),)
  result=plugin.execute_batch(ExecuteBatchRequest(source=source,bars=bars,context=MarketContext('binance','spot','BTCUSDT','1m'),options={'pineSessionId':'negative'}))
  assert result.ok,result.diagnostics
  message=_plugin_snapshot_or_patch_from_result('client',meta,list(bars),result,bar_time=bars[-1].time)
  rows.append({'formingClose':close,'expectedChangedPoint':result.output.series[0].points[-1].to_wire(),'websocketPatch':message})
finally:plugin.shutdown()
assert rows[0]['expectedChangedPoint']['time']==rows[1]['expectedChangedPoint']['time']==history[-1].time
assert rows[0]['expectedChangedPoint']['value']==102 and rows[1]['expectedChangedPoint']['value']==103
assert all(row['websocketPatch']['lines'][0]['data']==[] for row in rows),'Original omission no longer reproduced'
print(json.dumps({'reproduced':True,'source':'Actual pinned engine/current source bridge/current host payload adapter, no market/HTTP/UI. Forming close changes previous displayed point; final websocket patch drops it.','observations':rows},indent=2))
