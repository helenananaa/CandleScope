#!/bin/sh
exec /usr/bin/sandbox-exec -f '/Users/ryanliang/.codex/worktrees/history-study-mode-links-20261103/CandleScope/output/history-study-mode-notice-native-20261103/loopback-only.sb' '/Users/ryanliang/.codex/worktrees/history-study-mode-links-20261103/CandleScope/output/history-study-mode-notice-native-20261103/Installed App/CandleScope.app/Contents/MacOS/CandleScope' "$@"
