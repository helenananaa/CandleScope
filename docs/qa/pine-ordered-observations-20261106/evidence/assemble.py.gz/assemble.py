from pathlib import Path
import json,subprocess,hashlib,shutil
from app_copy import clone_app
root=Path.cwd();out=Path(__file__).parent/'native'
base=Path('/Users/ryanliang/CandleScope/output/development-goal-20261104/chart-source-wait-recovery-20261106/native/source-package-manifest.json')
x=json.loads(base.read_text());source=Path(x['app']).resolve(strict=True)
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
changed=subprocess.check_output(['git','diff','--name-only',x['sourceCommit'],'HEAD','backend/app','packages'],text=True).splitlines()
expected=['backend/app/api/v1/chart_calculation.py','backend/app/api/v1/chart_calculation_stream.py','backend/app/data_engine/data_manager/event_bus.py','backend/app/data_engine/data_manager/manager.py']
assert changed==expected,changed
for name,digest in x['files'].items():
 if name not in expected:assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
subprocess.run(['codesign','--verify','--deep','--strict',str(source)],check=True)
app=out/'Installed App/CandleScope.app';clone_app(source,app);res=app/'Contents/Resources'
for relative in expected:
 target=res/relative;assert not target.is_symlink();shutil.copy2(root/relative,target)
 x['files'][relative]=hashlib.sha256(target.read_bytes()).hexdigest()
subprocess.run([str(res/'python-runtime/python/bin/python3.12'),'-m','compileall','-q',*[str(res/f) for f in expected]],check=True)
subprocess.run(['codesign','--force','--deep','--sign','-',str(app)],check=True);subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True)
x.update(runtimeSource=str(source),app=str(app),sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),assembly='Physical source-resolving APFS clone of verified02 runtime; only four backend files overlaid/compiled and strictly signed. All1072 source/SDK fingerprints, inherited ASAR/plugins verified. No frontend or release rebuild.')
assert hashlib.sha256((res/'app.asar').read_bytes()).hexdigest()==x['asarSha256']
for name,digest in x['files'].items():
 if not name.startswith('frontend/'):assert hashlib.sha256((res/name).read_bytes()).hexdigest()==digest,name
for name,digest in x['plugins'].items():assert hashlib.sha256((res/name).read_bytes()).hexdigest()==digest,name
(out/'source-package-manifest.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({'source':x['sourceCommit'],'app':x['app'],'files':len(x['files']),'asar':x['asarSha256']}))
