import fs from 'node:fs/promises';
import * as q from 'file:///Users/ryanliang/.codex/worktrees/chart-strategy-sessions-20261104/CandleScope/docs/qa/indicator-domain-native-20261106/native-driver.mjs';
q.s.env={...q.s.env,CANDLESCOPE_RUNTIME_MODE:'LIVE',PYTHONUNBUFFERED:'1',PYTHONDONTWRITEBYTECODE:'1'};
let stop=false;
const observer=(async()=>{
 while(!stop&&!q.s.page)await q.delay(50);
 while(!stop){
  try{
   const ui=await q.s.page.evaluate(()=>({monitor:window.__CANDLESCOPE_INDICATOR_MONITOR__?.snapshot(),broker:window.__CANDLESCOPE_WINDOW_BROKER__?.snapshot({compact:true})}));
   const backend=await fetch(q.s.backend+'/api/v1/indicators/diagnostics',{signal:AbortSignal.timeout(4000)}).then(r=>r.json());
   const source=await fetch(q.s.backend+'/debug/snapshot',{signal:AbortSignal.timeout(4000)}).then(r=>r.json());
   await fs.appendFile(q.s.root+'/admission-observations.ndjson',JSON.stringify({at:Date.now(),ui,backend,source:{coordinator:source.coordinator,bar_delivery:source.bar_delivery,event_bus:source.event_bus,cache:source.cache}})+'\n');
  }catch(error){await fs.appendFile(q.s.root+'/observer-errors.ndjson',JSON.stringify({at:Date.now(),error:String(error)})+'\n').catch(()=>{});}
  for(let i=0;i<25&&!stop;i++)await q.delay(100);
 }
})();
try {await import('./boundary-acceptance.mjs');}
finally{stop=true;await observer;}
