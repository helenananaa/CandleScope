from pathlib import Path
import subprocess,os,time,json
B=Path(__file__).parent
R=Path('/Users/ryanliang/.codex/worktrees/chart-strategy-sessions-20261104/CandleScope')
N=B/'native'
env={**os.environ,'CANDLESCOPE_BATCH1_QA_ROOT':str(N),'CANDLESCOPE_PLAYWRIGHT_PACKAGE':'/Users/ryanliang/CandleScope/output/development-goal-20261104/native-tooling-20261106/package.json'}
observed={}
with (B/'native.log').open('w') as log:
 p=subprocess.Popen(['node',str(N/'observed-acceptance.mjs')],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
 def capture():
  rows={}
  for line in subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines():
   row=line.strip().split(None,2)
   if len(row)==3:rows[int(row[0])]={'pid':int(row[0]),'ppid':int(row[1]),'args':row[2]}
  chosen={p.pid}
  while True:
   children={pid for pid,row in rows.items() if row['ppid'] in chosen}
   if children<=chosen:break
   chosen|=children
  observed.update({pid:row for pid,row in rows.items() if pid in chosen and pid!=p.pid})
 while p.poll() is None:
  capture();(N/'independently-observed-processes.json').write_text(json.dumps(list(observed.values()),indent=2));time.sleep(.5)
 def alive(pid):
  try:os.kill(pid,0);return True
  except ProcessLookupError:return False
 receipt=json.loads((N/'acceptance.json').read_text())
 result={'source':json.loads((N/'source-package-manifest.json').read_text())['sourceCommit'],'exitCode':p.returncode,'owned':list(observed.values()),'remaining':[pid for pid in observed if alive(pid)],'sidecar':json.loads((N/'sidecar-exit-status.json').read_text()),'functionalQualified':receipt.get('passed'),'failure':receipt.get('failure'),'steps':[x['name'] for x in receipt.get('steps',[])]}
 (N/'independent-post-exit.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='owned'}))
 verify=subprocess.run(['node','docs/qa/indicator-domain-native-20261106/verify.mjs'],cwd=R,env=env,capture_output=True,text=True)
 (N/'post-exit-verification.log').write_text(verify.stdout+verify.stderr)
 assert not result['remaining'] and verify.returncode==0
 raise SystemExit(p.returncode)
