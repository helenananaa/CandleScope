#!/bin/sh
exec /usr/bin/sandbox-exec -f '/Users/ryanliang/.codex/worktrees/replay-manager-lifecycle-20261103/CandleScope/output/replay-view-date-native-window-20261103/loopback-only.sb' '/Users/ryanliang/.codex/worktrees/replay-manager-lifecycle-20261103/CandleScope/output/replay-view-date-native-window-20261103/Installed App/CandleScope.app/Contents/MacOS/CandleScope' "$@"
