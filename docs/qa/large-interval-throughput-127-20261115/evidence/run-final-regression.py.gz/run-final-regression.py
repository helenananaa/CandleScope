import json, os, pathlib, subprocess, time
root=pathlib.Path.cwd();out=root/'output/large-interval-throughput-127-20261115'
files=set(json.loads((out/'regression-modules.json').read_text()))
files.update(['backend/tests/test_gap_audit_series.py','backend/tests/test_dependent_invalidation_work.py','backend/tests/test_backfill_interest_priority.py'])
# Include all changed test modules, including imported Claude work.
changed=subprocess.check_output(['git','diff','--name-only','origin/main','--','backend/tests'],text=True).splitlines()
files.update(x for x in changed if pathlib.Path(x).name.startswith('test_') and x.endswith('.py'))
files=sorted(files)
assert all((root/x).is_file() for x in files),[x for x in files if not (root/x).is_file()]
(out/'regression-modules-final.json').write_text(json.dumps(files,indent=2)+'\n')
env=dict(os.environ,PYTHONPATH=str(root/'backend'));began=time.monotonic()
with (out/'backend-regression-final.log').open('w') as log:
 result=subprocess.run([str(root/'.venv/bin/python'),'-m','pytest','-q',*files],env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'regression-result.json').write_text(json.dumps(dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),module_count=len(files),exit_code=result.returncode,elapsed_seconds=round(time.monotonic()-began,3)),indent=2)+'\n')
print((out/'backend-regression-final.log').read_text()[-6000:]);raise SystemExit(result.returncode)
