"""Explicit diagnostic-only loader; no source writes or market substitutions."""
import importlib.abc, importlib.machinery, sys
class DiagnosticLoader(importlib.machinery.SourceFileLoader):
 def get_code(self, fullname):
  source=self.get_data(self.path).decode()
  old='''        except (RevisionUnavailable, StaleAcquisition):
            return _pending(symbol, interval, context, "revision_unavailable", min_revision)'''
  new='''        except (RevisionUnavailable, StaleAcquisition):
            import logging, traceback
            logging.getLogger('qa.revision-trace').warning('DIAGNOSTIC ONLY pending %s %s: %s', symbol, interval, traceback.format_exc())
            return _pending(symbol, interval, context, "revision_unavailable", min_revision)'''
  assert old in source
  return compile(source.replace(old,new),self.path,'exec')
class DiagnosticFinder(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname!='app.data_engine.data_manager.revisions': return None
  spec=importlib.machinery.PathFinder.find_spec(fullname,path)
  spec.loader=DiagnosticLoader(fullname,spec.origin)
  return spec
sys.meta_path.insert(0,DiagnosticFinder())
