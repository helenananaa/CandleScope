import gzip,hashlib,json,pathlib,shutil,subprocess
root=pathlib.Path.cwd();out=root/'output/large-interval-throughput-127-20261115';ev=root/'docs/qa/large-interval-throughput-127-20261115/evidence';ev.mkdir(exist_ok=True)
index=[];runs=[]
def archive(src,dst):
 data=src.read_bytes();target=ev/(dst+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));index.append(dict(source=str(src.relative_to(root)),archive=str(target.relative_to(root)),sha256=hashlib.sha256(data).hexdigest()))
for n in range(1,14):
 run=out/('native-four-cold'+(f'-{n}' if n>1 else ''));p=run/'acceptance.json'
 if not p.exists():continue
 d=json.loads(p.read_text());assert 'passed' in d,(run,'still running')
 steps=d['steps'];cold=next((s['evidence'] for s in steps if s['name']=='cold-prime-targets'),None)
 failure=next((s['evidence']['workspace'] for s in steps if s['name']=='failure-state'),None)
 samples=[json.loads(line) for line in (run/'resource-samples.jsonl').read_text().splitlines()] if (run/'resource-samples.jsonl').exists() else []
 runs.append(dict(run=run.name,source_commit=d['sourceCommit'],driver_source_commit=d['driverSourceCommit'],driver_sha256=d.get('driverSha256'),passed=d['passed'],failure=d.get('failure'),cold_elapsed_ms=cold.get('elapsedMs') if cold else None,cold_closed_comparisons={x['interval']:x['compared'] for x in cold['values']} if cold else None,failed_ui_counts={c['session']['interval']:c['runtime']['barCount'] for c in failure['cells']} if isinstance(failure,dict) else None,steps=[dict(name=s['name'],at=s['at']) for s in steps],errors=d['errors'],peak_owned_rss_mib=round(max(s.get('rssKiB',0) for s in samples)/1024,2) if samples else None,resource_scope='sum of owned process RSS; shared pages may be counted multiple times; no paired baseline',numeric_comparison=d.get('numericComparison'),canonical_checks=[dict(stage=s['name'],closed={v['interval']:v['compared'] for v in s['evidence']['values']},roundoff=s['evidence'].get('additiveRoundoff',[])) for s in steps if isinstance(s.get('evidence'),dict) and isinstance(s['evidence'].get('values'),list)]))
 for name in ('acceptance.json','ambient-load-before.txt','driver.log','resource-samples.jsonl','profile/logs/backend-sidecar.log','pre-controls-snapshot.json','strict-range-final-responses.json'):
  src=run/name
  if src.exists():archive(src,run.name+'-'+name.replace('/','-'))
 if d['passed']:
  traffic=json.loads((run/'traffic.json').read_text())
  strict=[row for row in traffic['responses'] if '/klines/range?' in row['url'] and 'interval=10007m' in row['url'] and 'strict=true' in row['url']]
  selected=run/'strict-range-final-responses.json';selected.write_text(json.dumps(strict,indent=2)+'\n');archive(selected,run.name+'-strict-range-final-responses.json')
  for name in ('cold-primes.png','steady-primes.png','restored-visible.png','recreated-primes.png','restarted-primes.png'):
   shutil.copyfile(run/name,ev/name)
for candidate in ('candidate-8','candidate-10','candidate-11','candidate-13'):
 for name in ('package-source-manifest.json','sign.log','sign-verify.log','sign-after.log','package-after.json'):
  src=out/candidate/name
  if src.exists():archive(src,candidate+'-'+name)
for name in ('backend-regression-final.log','regression-modules-final.json','regression-result.json','architecture-final.log','numeric-final.log','run-final-regression.py','retain-evidence.py','verify-candidate.py','regression-after-native.py','replay-warm-query.py','warm-query-diagnostic.log','large-repair-qualification-final.log','archive-source-budget-final.log','closed-target-snapshot-final-verified.log','read-proof-and-preview-final.log','backend-regression-before-preview-recheck.log','regression-before-preview-recheck.json'):
 src=out/name
 if src.exists():archive(src,name)
for diagnostic in ('native-warm-diagnostic-11','native-cold-diagnostic-12'):
 run=out/diagnostic
 for name in ('acceptance.json','driver.log','profile/logs/backend-sidecar.log'):
  src=run/name
  if src.exists():
   archive(src,'diagnostic-'+diagnostic+'-'+name.replace('/','-'))
   index[-1]['qualification']=False
for name in ('warm-diagnostic-probe.mjs','warm-trace-bootstrap/sitecustomize.py','replay-warm-query-11.py','warm-query-diagnostic-11.log'):
 src=out/name
 if src.exists():
  archive(src,'diagnostic-'+name.replace('/','-'))
  index[-1]['qualification']=False
# A successful run's selected strict responses are generated during retention.
unique={entry['archive']:entry for entry in index};index=list(unique.values())
(ev/'index.json').write_text(json.dumps(index,indent=2)+'\n');(ev/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(runs[-1],indent=2))
