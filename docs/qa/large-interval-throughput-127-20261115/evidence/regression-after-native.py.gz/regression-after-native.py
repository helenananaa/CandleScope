import json,pathlib,subprocess,sys,time
root=pathlib.Path.cwd();out=root/'output/large-interval-throughput-127-20261115';receipt=out/sys.argv[1]/'acceptance.json';deadline=time.monotonic()+3600
while time.monotonic()<deadline:
 try:d=json.loads(receipt.read_text())
 except (OSError,json.JSONDecodeError):d={}
 if 'passed' in d:
  if not d['passed']:raise SystemExit('Native run failed; final regression not launched')
  assert len([s for s in d['steps'] if s['name']=='full-process-exit'])==2
  break
 time.sleep(3)
else:raise SystemExit('Native run did not finish within one hour')
print('Native full lifecycle passed; starting final backend regression',flush=True)
raise SystemExit(subprocess.run(['python3',str(out/'run-final-regression.py')],cwd=root).returncode)
