import asyncio,json,pathlib,sqlite3,time
from app.core import config as core_config
from app.data_engine.storage import klines_repo
from app.data_engine.data_manager import DataManager
from app.data_engine.data_manager.config import DataManagerConfig
root=pathlib.Path.cwd();out=root/'output/large-interval-throughput-127-20261115';source=out/'native-four-cold-11/profile/data/candlescope.db';target=out/'warm-query-diagnostic-11.sqlite'
assert not target.exists()
a=sqlite3.connect('file:'+str(source)+'?mode=ro',uri=True);b=sqlite3.connect(target);a.backup(b);b.close();a.close()
core_config.KLINES_DB_PATH=klines_repo.KLINES_DB_PATH=target;klines_repo.init_klines_storage();cfg=DataManagerConfig();cfg.query.auto_backfill=False;dm=DataManager(cfg);dm.set_storage(klines_repo.KlinesRepoAdapter());engine=dm.query_engine
for contract in (None,engine._interval_resolver.history_composition_routes(exchange='binance',market_type='futures',interval='10007m')[0].contract_id):
 began=time.monotonic();kwargs={'composition_contract':contract} if contract else {};result=engine.query('BTCUSDT','10007m',start_ms=1717801620000,end_ms=1794054960000,limit=2000,exchange='binance',market_type='futures',auto_backfill=False,**kwargs);d=dict(contract=contract,elapsed=time.monotonic()-began,bars=len(result.bars),complete=result.complete,retryable=result.retryable,state=result.history_state,metadata=result.metadata,missing=[str(x) for x in result.missing_ranges]);print(json.dumps(d,default=str,indent=2),flush=True)
asyncio.run(dm.shutdown())
