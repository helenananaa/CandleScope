import ast,hashlib,json,pathlib,subprocess
root=pathlib.Path.cwd();candidate=root/'output/large-interval-throughput-127-20261115/candidate-13';manifest=json.loads((candidate/'package-source-manifest.json').read_text());resources=candidate/'CandleScope.app/Contents/Resources'
class WithoutDocstrings(ast.NodeTransformer):
 def clean(self,node):
  self.generic_visit(node)
  if node.body and isinstance(node.body[0],ast.Expr) and isinstance(node.body[0].value,ast.Constant) and isinstance(node.body[0].value.value,str):node.body.pop(0)
  return node
 visit_Module=clean
 visit_ClassDef=clean
 visit_FunctionDef=clean
 visit_AsyncFunctionDef=clean
def semantic(source):return ast.dump(WithoutDocstrings().visit(ast.parse(source)),include_attributes=False)
docs_only=[]
for name,digest in manifest['files'].items():
 packaged=(resources/name).read_bytes();current=(root/name).read_bytes()
 assert hashlib.sha256(packaged).hexdigest()==digest,name
 if current!=packaged:
  assert name.endswith('.py') and semantic(current)==semantic(packaged),name
  docs_only.append(name)
assert hashlib.sha256((resources/'app.asar').read_bytes()).hexdigest()==manifest['app_asar_sha256']
assert not subprocess.check_output(['git','diff','--name-only',manifest['frontend_source_head'],'HEAD','--',*manifest['retained_paths_unchanged']],text=True)
result=subprocess.run(['codesign','--verify','--deep','--strict',str(candidate/'CandleScope.app')],capture_output=True,text=True);(candidate/'sign-after.log').write_text(result.stdout+result.stderr);assert result.returncode==0
summary=dict(verification_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),product_source_commit=manifest['product_head'],checked_backend_files=len(manifest['files']),all_packaged_source_hashes_match=True,unchanged_app_asar_sha256=manifest['app_asar_sha256'],current_backend_ast_matches=True,current_source_docstrings_or_comments_only_differences=docs_only,frontend_dependency_source_parity=True,strict_signature_verified=True)
(candidate/'package-after.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
