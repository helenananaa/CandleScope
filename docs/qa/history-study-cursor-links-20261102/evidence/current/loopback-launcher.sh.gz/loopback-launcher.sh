#!/bin/sh
exec /usr/bin/sandbox-exec -f '/Users/ryanliang/.codex/worktrees/history-study-cursor-links-20261102/CandleScope/output/history-study-cursor-recovery-native-20261103/loopback-only.sb' '/Users/ryanliang/.codex/worktrees/history-study-cursor-links-20261102/CandleScope/output/history-study-cursor-recovery-native-20261103/Installed App/CandleScope.app/Contents/MacOS/CandleScope' "$@"
