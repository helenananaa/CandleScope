from pathlib import Path
import hashlib,json,subprocess,shutil,os
from app_copy import clone_app
root=Path.cwd()
out=Path(__file__).parent/'native'
base=Path('/Users/ryanliang/CandleScope/output/development-goal-20261104/indicator-range-domain-native-20261106/source-package-manifest.json')
original=json.loads(base.read_text())
source=Path(original['app']).resolve(strict=True)
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for tree in ('frontend','packages'):
 assert subprocess.check_output(['git','rev-parse',f'HEAD:{tree}'])==subprocess.check_output(['git','rev-parse',f"{original['sourceCommit']}:{tree}"]),tree
subprocess.run(['codesign','--verify','--deep','--strict',str(source)],check=True)
for file in ('requirements.txt','ccxt-fork.lock.json'):
 assert (source/'Contents/Resources/backend'/file).read_bytes()==(root/'backend'/file).read_bytes()
app=out/'Installed App/CandleScope.app'
clone_app(source,app)
res=app/'Contents/Resources'
shutil.rmtree(res/'backend/app')
tracked=subprocess.check_output(['git','ls-files','-z','backend/app'],text=True).split('\0')
for file in filter(None,tracked):
 target=res/file;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/file,target)
for file,digest in original['files'].items():
 if not file.startswith('backend/app/') and not file.startswith('frontend/'):
  assert hashlib.sha256((res/file).read_bytes()).hexdigest()==digest,file
subprocess.run([str(res/'python-runtime/python/bin/python3.12'),'-m','compileall','-q',str(res/'backend/app')],check=True)
subprocess.run(['codesign','--force','--deep','--sign','-',str(app)],check=True)
subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True)
files={}
for file in filter(None,tracked):
 data=(root/file).read_bytes();assert (res/file).read_bytes()==data,file;files[file]=hashlib.sha256(data).hexdigest()
for file,digest in original['plugins'].items():assert hashlib.sha256((res/file).read_bytes()).hexdigest()==digest,file
assert hashlib.sha256((res/'app.asar').read_bytes()).hexdigest()==original['asarSha256']
receipt={**original,'sourceCommit':head,'assembly':'Isolated physical APFS clone; complete current tracked backend replacement, compile and strict ad-hoc signature. Unchanged frontend/packages Git trees and complete inherited ASAR/plugins verified. No full release build or fresh frontend build.','runtimeSource':str(source),'app':str(app),'files':{**{k:v for k,v in original['files'].items() if not k.startswith('backend/app/')},**files},'mismatches':[]}
(out/'source-package-manifest.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'source':head,'app':str(app),'backendFiles':len(files),'plugins':len(original['plugins']),'asarSha256':original['asarSha256']}))
