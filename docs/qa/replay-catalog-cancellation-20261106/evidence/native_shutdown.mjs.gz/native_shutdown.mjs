import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import * as q from './native-driver.mjs';
q.s.receipt.scope='Current main plus owned catalog cancellation: actual macOS LIVE startup, active catalog, one no-Pine chart, save, complete quit/restart. No claim of live Pine, full catalog completion, release build, or Windows acceptance.';
q.s.env={...q.s.env,CANDLESCOPE_RUNTIME_MODE:'LIVE',PYTHONUNBUFFERED:'1',PYTHONDONTWRITEBYTECODE:'1'};
let launched=false;
try {
 for(let round=0;round<2;round++) {
  await q.assertPublicGate();
  await q.record('launch-'+round,await q.launch());launched=true;
  await q.s.page.getByRole('button',{name:'设置',exact:true}).waitFor({timeout:60000});
  await q.checkCircuit();
  const snapshot=await fetch(q.s.backend+'/debug/snapshot').then(r=>r.json());
  await fs.writeFile(q.s.root+'/debug-before-quit-'+round+'.json',JSON.stringify(snapshot,null,2));
  await q.record('catalog-active-'+round,snapshot.replay?.trade_history);
  assert.equal(snapshot.replay?.trade_history?.catalog_refreshing,true,'Exercise actual ongoing official catalog');
  if(round===0){
   await q.enableControl();
   await q.record('configure-no-pine',await q.configure([{session:q.session('BTCUSDT','1m'),indicators:[]}],'single'));
   await q.ready(1,60000);
   await q.record('workspace-saved',await q.inspect());
  } else {
   const state=await q.s.page.evaluate(()=>window.__CANDLESCOPE_WINDOW_BROKER__?.snapshot({compact:true}));
   await q.record('restored-window',state);
  }
  await q.checkCircuit();
  await q.quit();
  assert.equal(await q.exited(),true);launched=false;
  const status=JSON.parse(await fs.readFile(q.s.root+'/sidecar-exit-status.json','utf8'));
  const pid=q.s.exitObserver.pid;
  assert.ok(status.exits.some(x=>x.pid===pid&&x.code===0&&x.signal===null));
  assert.ok(!status.killRequests.some(x=>x.pid===pid&&x.signal==='SIGKILL'));
  await q.record('unforced-exit-'+round,{pid,status,elapsedMs:Date.now()-q.s.quitStartedAt});
 }
 q.s.receipt.qualified=true;
} catch(error) {q.s.receipt.failure=String(error.stack||error);process.exitCode=1;}
finally {
 if(launched){try{await q.quit();q.s.receipt.cleanupOwnedExited=await q.exited();}catch(error){q.s.receipt.cleanupFailure=String(error.stack||error);process.exitCode=1;}}
 q.s.receipt.completedAt=new Date().toISOString();await q.save();
 console.log(JSON.stringify({qualified:q.s.receipt.qualified,failure:q.s.receipt.failure,cleanupFailure:q.s.receipt.cleanupFailure}));
}
