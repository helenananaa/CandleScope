import json,os,subprocess,datetime
from pathlib import Path
p=Path(__file__).parent/'checks.json'
x=json.loads(p.read_text());x['started']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(x,indent=2)+'\n')
Path('/tmp/candlescope-catalog-owned-20261106').mkdir(parents=True,exist_ok=True)
with (p.parent/'backend-combined.log').open('w') as log:result=subprocess.run(x['command'],env={**os.environ,**x['env']},stdout=log,stderr=subprocess.STDOUT)
x['exitCode']=result.returncode;x['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({'source':x['source'],'exitCode':x['exitCode']}));raise SystemExit(result.returncode)
