"""Exercise the actual service/repository boundary, with counted transport."""
import asyncio
from functools import wraps

import pytest

from app.data_engine.market_data.service import MarketDataService
from app.data_engine.market_data.models import MarketStreamKey, MarketChannel
from app.data_engine.storage.market_metrics_repo import MarketMetricsRepository
from app.data_engine.ingestion.models import MarketEvent, DataSource

STEP = 300_000
NOW = 1_800_000_000_000
START = NOW - 20 * STEP
KEY = MarketStreamKey.build("binance", "futures", "BTCUSDT", MarketChannel.OPEN_INTEREST)


def async_test(fn):
    @wraps(fn)
    def run(*args, **kwargs):
        return asyncio.run(fn(*args, **kwargs))
    return run


class Transport:
    def __init__(self):
        self.calls = []
        self.empty = False
        self.block = None
        self.started = asyncio.Event()
        self.cancelled = False

    async def fetch_market(self, descriptor, **kwargs):
        self.calls.append(kwargs)
        self.started.set()
        if self.block is not None:
            try:
                await self.block.wait()
            except asyncio.CancelledError:
                self.cancelled = True
                raise
        if self.empty:
            return []
        return [MarketEvent(
            event_type=descriptor.stream_type, symbol=descriptor.symbol,
            exchange=descriptor.exchange, market_type=descriptor.market_type,
            event_time_ms=t, received_at_ms=NOW, source=DataSource.HTTP_BACKFILL,
            data={"open_interest": 200.0}, stream_key=descriptor.key,
        ) for t in range(kwargs["start_ms"], kwargs["end_ms"] + 1, STEP)]


def make_service(tmp_path, monkeypatch):
    monkeypatch.setattr("app.data_engine.market_data.service.time.time", lambda: NOW / 1000)
    repo = MarketMetricsRepository(tmp_path / "metrics.sqlite")
    transport = Transport()
    return repo, transport, MarketDataService(transport, metrics_repository=repo)


def seed(repo, times, *, final=True, received=NOW):
    repo.upsert_open_interest([dict(
        exchange="binance", market_type="futures", symbol="BTCUSDT", period="5m",
        event_time_ms=t, open_interest=100, is_final=final,
        received_at_ms=received, source="http_backfill" if final else "http",
    ) for t in times])


async def query(service, **kwargs):
    return await service.history_page(KEY, period="5m", start_ms=START,
                                      end_ms=START + 4 * STEP, **kwargs)


@async_test
async def test_committed_stable_history_survives_service_restart_without_network(tmp_path, monkeypatch):
    repo, transport, service = make_service(tmp_path, monkeypatch)
    seed(repo, range(START, START + 5 * STEP, STEP))
    for _ in range(2):
        page = await query(service)
        assert page.complete and not page.retryable
        assert len(page.events) == 5
        assert transport.calls == []
        await service.shutdown()
        service = MarketDataService(transport, metrics_repository=repo)
    await service.shutdown()


@async_test
async def test_only_internal_holes_are_fetched_and_explicit_refresh_revises_all(tmp_path, monkeypatch):
    repo, transport, service = make_service(tmp_path, monkeypatch)
    seed(repo, [START, START + 2 * STEP, START + 4 * STEP])
    local = await query(service, mode="local_only")
    assert len(local.covered_ranges) == 3 and len(local.missing_ranges) == 2
    assert not local.complete and not local.retryable and transport.calls == []
    filled = await query(service)
    assert filled.complete
    assert [(c["start_ms"], c["end_ms"], c["limit"]) for c in transport.calls] == [
        (START + STEP, START + STEP, 1), (START + 3 * STEP, START + 3 * STEP, 1),
    ]
    refreshed = await query(service, mode="refresh")
    assert refreshed.complete
    assert transport.calls[-1]["limit"] == 5
    assert all(e.data["open_interest"] == 200 for e in refreshed.events)
    await service.shutdown()


@async_test
async def test_short_empty_response_never_certifies_missing_or_provisional_points(tmp_path, monkeypatch):
    repo, transport, service = make_service(tmp_path, monkeypatch)
    seed(repo, [START, START + 4 * STEP])
    seed(repo, [START + STEP], final=False)
    transport.empty = True
    page = await query(service)
    assert page.retryable and not page.complete
    assert len(page.covered_ranges) == 2
    assert page.missing_ranges == ({"start_ms": START + STEP, "end_ms": START + 4 * STEP - 1},)
    await service.shutdown()


@async_test
async def test_overlap_waits_for_commit_and_one_cancel_does_not_cancel_shared_fetch(tmp_path, monkeypatch):
    _, transport, service = make_service(tmp_path, monkeypatch)
    transport.block = asyncio.Event()
    a = asyncio.create_task(query(service))
    b = asyncio.create_task(query(service))
    await transport.started.wait()
    a.cancel()
    with pytest.raises(asyncio.CancelledError):
        await a
    assert not transport.cancelled
    c = asyncio.create_task(service.history_page(KEY, period="5m", start_ms=START + STEP,
                                                 end_ms=START + 4 * STEP))
    transport.block.set()
    assert (await b).complete and (await c).complete
    assert len(transport.calls) == 1
    assert not service._history_tasks
    await service.shutdown()


@async_test
async def test_last_waiter_cancel_and_shutdown_drain_owned_tasks(tmp_path, monkeypatch):
    _, transport, service = make_service(tmp_path, monkeypatch)
    transport.block = asyncio.Event()
    task = asyncio.create_task(query(service))
    await transport.started.wait()
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    assert transport.cancelled and not service._history_tasks
    transport.started.clear()
    task = asyncio.create_task(query(service))
    await transport.started.wait()
    await service.shutdown()
    with pytest.raises(asyncio.CancelledError):
        await task
    assert not service._history_tasks


@async_test
async def test_expired_gaps_are_unavailable_but_local_rows_remain_readable(tmp_path, monkeypatch):
    repo, transport, service = make_service(tmp_path, monkeypatch)
    old = START - 40 * 86_400_000
    seed(repo, [old])
    page = await service.history_page(KEY, period="5m", start_ms=old, end_ms=old + STEP)
    assert len(page.events) == 1 and transport.calls == []
    assert page.complete and not page.retryable
    assert page.excluded_ranges[-1]["reason"] == "outside_upstream_retention"
    await service.shutdown()


@async_test
async def test_large_query_is_bounded_and_mutable_tail_is_revalidated(tmp_path, monkeypatch):
    repo, transport, service = make_service(tmp_path, monkeypatch)
    page = await service.history_page(KEY, period="5m", start_ms=NOW - 10_000 * STEP,
                                      end_ms=NOW - 10 * STEP, limit=1000)
    assert len(page.events) == 500 and page.has_more and not page.complete
    assert transport.calls[-1]["limit"] == 500
    seed(repo, [NOW], received=NOW - 120_000)
    before = len(transport.calls)
    tail = await service.history_page(KEY, period="5m", start_ms=NOW, end_ms=NOW)
    assert tail.complete and len(transport.calls) == before + 1
    await service.history_page(KEY, period="5m", start_ms=NOW, end_ms=NOW)
    assert len(transport.calls) == before + 1
    await service.shutdown()


@async_test
async def test_http_contract_uses_real_service_and_does_not_turn_short_page_into_coverage(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from fastapi import FastAPI
    import httpx
    from app.api.v1.market import router

    repo, transport, service = make_service(tmp_path, monkeypatch)
    seed(repo, [START, START + 4 * STEP])
    app = FastAPI()
    app.include_router(router)
    app.state.data_manager = SimpleNamespace(market_data_ready=True, market_history_page=service.history_page)
    params = dict(channel="open_interest", symbol="BTCUSDT", period="5m", start_ms=START,
                  end_ms=START + 4 * STEP, mode="local_only")
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/market/history", params=params)
        assert response.status_code == 200
        body = response.json()
        assert body["query_mode"] == "local_only" and not body["complete"]
        assert len(body["coverage"]["ranges"]) == 2 and len(body["coverage"]["missing_ranges"]) == 1
        assert transport.calls == []
        params["mode"] = "fill_missing"
        response = await client.get("/market/history", params=params)
        assert response.json()["complete"] is True
        assert len(transport.calls) == 1
        params["mode"] = "bad"
        assert (await client.get("/market/history", params=params)).status_code == 422
    await service.shutdown()
