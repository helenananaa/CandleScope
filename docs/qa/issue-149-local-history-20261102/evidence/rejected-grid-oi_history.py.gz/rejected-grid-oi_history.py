"""Bounded interpretation of the native Binance OI timestamp grid.

Coverage is derived from committed final samples on every read. No separate
inventory or negative cache can outlive edits to the metric repository.
"""

from dataclasses import dataclass
from collections.abc import Iterable

from .events import MarketStateEvent


@dataclass(frozen=True, slots=True)
class OpenInterestWindow:
    start_ms: int
    end_ms: int
    step_ms: int
    first_ms: int
    last_ms: int
    has_earlier: bool

    @classmethod
    def build(cls, start_ms: int, end_ms: int, step_ms: int, limit: int):
        first = ((start_ms + step_ms - 1) // step_ms) * step_ms
        last = (end_ms // step_ms) * step_ms
        bounded_first = max(first, last - (limit - 1) * step_ms)
        has_earlier = bounded_first > first
        return cls(
            bounded_first if has_earlier else start_ms,
            end_ms, step_ms, bounded_first, last, has_earlier,
        )

    def timestamps(self) -> range:
        return range(self.first_ms, self.last_ms + 1, self.step_ms)

    def ranges(self, timestamps: Iterable[int]) -> tuple[dict, ...]:
        """Compress timestamp cells without bridging an absent observation."""
        result: list[dict] = []
        for stamp in sorted(set(timestamps)):
            start = self.start_ms if stamp == self.first_ms else stamp
            end = min(stamp + self.step_ms - 1, self.end_ms)
            if result and result[-1]["end_ms"] + 1 == start:
                result[-1]["end_ms"] = end
            else:
                result.append({"start_ms": start, "end_ms": end})
        return tuple(result)

    def qualified(self, events: Iterable[MarketStateEvent], now_ms: int) -> set[int]:
        # The last two intervals can still be revised by the provider. A fresh
        # REST observation is reusable for 60s, including after app restart.
        stable_before = (now_ms // self.step_ms - 2) * self.step_ms
        expected = self.timestamps()
        return {
            event.event_time_ms for event in events
            if event.event_time_ms in expected and event.data.get("is_final") is True
            and (event.event_time_ms < stable_before
                 or now_ms - 60_000 <= event.received_at_ms <= now_ms)
        }
