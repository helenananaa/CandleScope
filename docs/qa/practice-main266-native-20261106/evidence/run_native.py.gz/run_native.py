from pathlib import Path
import os,subprocess,time,json
B=Path(__file__).parent;N=B/'native';R=Path('/Users/ryanliang/.codex/worktrees/chart-strategy-sessions-20261104/CandleScope')
e={**os.environ,'CANDLESCOPE_BATCH1_QA_ROOT':str(N),'CANDLESCOPE_PLAYWRIGHT_PACKAGE':'/Users/ryanliang/CandleScope/output/development-goal-20261104/native-tooling-20261106/package.json'}
observed={}
with (B/'native.log').open('w') as log:
 p=subprocess.Popen(['node','docs/qa/practice-main266-native-20261106/native-practice.mjs'],cwd=R,env=e,stdout=log,stderr=subprocess.STDOUT)
 while p.poll() is None:
  rows={}
  for line in subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines():
   a=line.strip().split(None,2)
   if len(a)==3:rows[int(a[0])]={'pid':int(a[0]),'ppid':int(a[1]),'args':a[2]}
  chosen={p.pid}
  while True:
   children={pid for pid,row in rows.items() if row['ppid'] in chosen}
   if children<=chosen:break
   chosen|=children
  observed.update({pid:row for pid,row in rows.items() if pid in chosen and pid!=p.pid})
  (N/'independently-observed-processes.json').write_text(json.dumps(list(observed.values()),indent=2));time.sleep(.5)
 def absent(pid):
  try:os.kill(pid,0);return False
  except ProcessLookupError:return True
 a=json.loads((N/'acceptance.json').read_text());owned=[v for s in a['steps'] if s['name']=='quit-requested' for v in s['evidence']['owned']]
 result={'source':a.get('sourceCommit'),'exitCode':p.returncode,'functionalQualified':a.get('passed'),'failure':a.get('failure'),'ownedAppPids':owned,'allAppPidsAbsent':all(absent(x['pid']) for x in owned),'runnerDescendants':list(observed.values()),'remainingRunnerDescendants':[x for x in observed if not absent(x)],'sidecar':json.loads((N/'sidecar-exit-status.json').read_text()) if (N/'sidecar-exit-status.json').exists() else None}
 (N/'independent-post-exit.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['ownedAppPids','runnerDescendants']}));assert result['allAppPidsAbsent'] and not result['remainingRunnerDescendants'];raise SystemExit(p.returncode)
