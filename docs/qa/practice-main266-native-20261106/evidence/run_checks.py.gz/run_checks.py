import json,os,subprocess,datetime
from pathlib import Path
p=Path(__file__).parent/"checks.json"
x=json.loads(p.read_text());x["started"]=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(x,indent=2))
with (p.parent/"backend-combined.log").open("w") as log:r=subprocess.run(x["command"],env={**os.environ,**x["env"]},stdout=log,stderr=subprocess.STDOUT)
x["exitCode"]=r.returncode;x["finished"]=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(x,indent=2));print(json.dumps({"source":x["source"],"exitCode":r.returncode}));raise SystemExit(r.returncode)
