from pathlib import Path
import json,sqlite3
from decimal import Decimal as D
O=Path(__file__).parent;N=O/'native'
a=json.loads((N/'acceptance.json').read_text())
saved=next(s['evidence'] for s in a['steps'] if s['name']=='saved-flat-ledger')
restored=next(s['evidence'] for s in a['steps'] if s['name']=='full-restart-restored')
account=saved['view']['selected'];aid=account['id'];fills=saved['fills'];fees=[];cash=D(0)
for f in fills:
 assert f['feeCurrency']=='USDT' and f['source']=='practice' and f['liquidity']=='taker'
 price,qty=D(f['price']),D(f['qty']);rate=D(account['settings']['takerFeeRate']);fee=price*qty*rate
 assert fee==D(f['fee'])
 fees.append({'id':f['id'],'price':str(price),'qty':str(qty),'configuredRate':str(rate),'expectedFee':str(fee),'actualFee':f['fee']})
 cash+=(D(1) if f['side']=='sell' else D(-1))*price*qty-fee
assert sum((D(f['qty']) for f in fills if f['side']=='buy'),D(0))==sum((D(f['qty']) for f in fills if f['side']=='sell'),D(0))==D('0.001')
expected=D(account['settings']['initialBalance'])+cash
for v in [saved['view'],restored['view']]:
 assert not v['summary']['positions'] and not v['summary']['workingOrders']
 assert D(v['summary']['balance'])==D(v['summary']['equity'])==expected
 assert len(v['trades'])==1 and D(v['trades'][0]['netPnl'])==cash
with sqlite3.connect((N/'profile/data/trading-accounts.sqlite3').as_uri()+'?mode=ro',uri=True) as c:
 c.row_factory=sqlite3.Row;check=c.execute('PRAGMA quick_check').fetchone()[0];assert check=='ok'
 rows=[dict(r) for r in c.execute('select * from fills where account_id=? order by ts_ms,id',(aid,))]
 flows=[dict(r) for r in c.execute('select * from cash_flows where account_id=?',(aid,))]
 orders=[dict(r) for r in c.execute('select * from orders where account_id=? order by created_at_ms,id',(aid,))]
 cursor=dict(c.execute('select epoch,sequence from ledger_state_revision where id=1').fetchone())
 assert len(rows)==len(fills)==2
 for f in fills:
  row=next(r for r in rows if r['id']==f['id'])
  for native,db in [('side','side'),('qty','qty'),('price','price'),('fee','fee'),('feeCurrency','fee_currency'),('liquidity','liquidity'),('orderId','order_id'),('tsMs','ts_ms')]:assert row[db]==f[native]
 assert sum((D(f['amount']) for f in flows),D(0))==D('1000')
 assert sorted(r['status'] for r in orders)==['cancelled','filled','filled']
 assert cursor['epoch']==saved['cursor']['epoch']==restored['cursor']['epoch'] and cursor['sequence']>=restored['cursor']['sequence']
x={'scope':'Independent Decimal arithmetic from captured settings/fill prices; no application math imports; read-only post-exit SQLite witness','accountId':aid,'fills':fees,'expectedBalance':str(expected),'expectedNetPnl':str(cash),'savedAndRestoredEqual':True,'persistedFillsFullFieldsMatch':True,'persistedOrderStatuses':[r['status'] for r in orders],'initialCashFlows':flows,'persistedCursor':cursor,'sqliteQuickCheck':check}
(O/'independent-financial-oracle.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps({'balance':str(expected),'netPnl':str(cash),'allChecksPassed':True}))
