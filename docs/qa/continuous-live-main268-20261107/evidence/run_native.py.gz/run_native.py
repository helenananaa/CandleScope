import json
import os
import shutil
import socket
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
candidate = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else root / 'candidate'
seed_root = Path(sys.argv[3]).resolve() if len(sys.argv) > 3 else root
run = root / sys.argv[1]
run.mkdir()
shutil.copytree(seed_root / 'profile', run / 'profile')
for file in [seed_root / 'research-seed.json', candidate / 'source-package-manifest.json']:
    shutil.copy2(file, run / file.name)
app = (candidate / 'Installed App/CandleScope.app').resolve(strict=True)
(run / 'Installed App').mkdir()
(run / 'Installed App/CandleScope.app').symlink_to(app, target_is_directory=True)
with socket.socket() as listener:
    listener.bind(('127.0.0.1', 0))
    port = listener.getsockname()[1]
env = {
    'CANDLESCOPE_BATCH1_QA_ROOT': str(run),
    'CANDLESCOPE_QA_SEED_PROFILE': str(seed_root / 'profile'),
    'CANDLESCOPE_QA_UI_PORT': str(port),
    'CANDLESCOPE_PLAYWRIGHT_PACKAGE': str(root.parent / 'native-tooling-20261106/package.json'),
}
(run / 'launch-env.json').write_text(json.dumps(env, indent=2) + '\n')
with (run / 'native.log').open('w') as log:
    result = subprocess.run(['node', 'docs/qa/continuous-live-main268-20261107/native.mjs'],
                            env={**os.environ, **env}, stdout=log, stderr=subprocess.STDOUT)
print((run / 'native.log').read_text()[-2200:])
raise SystemExit(result.returncode)
