#!/bin/sh
exec /usr/bin/sandbox-exec -f '/Users/ryanliang/.codex/worktrees/replay-manager-service-20261103/CandleScope/output/replay-manager-service-native-closeout-20261103/loopback-only.sb' '/Users/ryanliang/.codex/worktrees/replay-manager-service-20261103/CandleScope/output/replay-manager-service-native-closeout-20261103/Installed App/CandleScope.app/Contents/MacOS/CandleScope' "$@"
