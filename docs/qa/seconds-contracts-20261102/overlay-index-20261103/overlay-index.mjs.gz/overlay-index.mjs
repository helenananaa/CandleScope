import fs from 'node:fs';import path from 'node:path';import {createRequire} from 'node:module';
const root=process.cwd(),out=path.join(root,'output/seconds-contracts-20261102/gate-renderer-repro');const {chromium}=createRequire('/Users/ryanliang/CandleScope/output/backend-goal-20261102/native-tooling/package.json')('playwright-core');
const raw=JSON.parse(fs.readFileSync(path.join(root,'output/seconds-contracts-20261102/indicator-coherent-diagnostic-native/canonical-last-cell-3.json')));
const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
try{const page=await browser.newPage({viewport:{width:1100,height:700}}),errors=[];page.on('pageerror',e=>errors.push(String(e.stack||e)));await page.setContent('<div id="chart" style="width:1000px;height:600px"></div>');await page.addScriptTag({path:path.join(root,'frontend/node_modules/lightweight-charts/dist/lightweight-charts.standalone.production.js')});const results=[];
 for(const away of [false,true])for(const optionsDirty of [false,true]){
  await page.mouse.move(1050,650);
  await page.evaluate(async ({raw,away})=>{
   Error.stackTraceLimit=50;const {createChart,CandlestickSeries,LineSeries}=LightweightCharts;const chart=createChart(document.querySelector('#chart'),{width:1000,height:600});const main=chart.addSeries(CandlestickSeries),line=chart.addSeries(LineSeries);
   const seed=raw.chart.bars.map(b=>({time:b.time,open:b.open,high:b.high,low:b.low,close:b.close}));const repaired=new Map(seed.map(b=>[b.time,b]));for(const b of raw.response.body.data)repaired.set(b.time,{time:b.time,open:b.open,high:b.high,low:b.low,close:b.close});const next=[...repaired.values()].sort((a,b)=>a.time-b.time);
   main.setData(seed);line.setData(seed.map(b=>({time:b.time,value:b.close})));chart.timeScale().fitContent();if(away)chart.timeScale().setVisibleLogicalRange({from:seed.length-50,to:seed.length-10});window.caseState={chart,main,line,seed,next};await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
  },{raw,away});await page.mouse.move(650,250,{steps:5});
  const result=await page.evaluate(({away,optionsDirty})=>{const {chart,main,line,seed,next}=window.caseState;try{if(optionsDirty)main.applyOptions({priceLineVisible:false});line.setData(next.map(b=>({time:b.time,value:b.close})));return {away,optionsDirty,passed:true,mainCount:main.data().length};}catch(e){return {away,optionsDirty,passed:false,error:String(e.stack||e)};}finally{chart.remove();}},{away,optionsDirty});results.push(result);
 }
 const receipt={scope:'Offline actual pinned LWC; recorded Gate sparse data; overlay inserts missing historical times while pointer and historical viewport active',results,errors};fs.writeFileSync(path.join(out,'overlay-index.json'),JSON.stringify(receipt,null,2));console.log(JSON.stringify(results));
}finally{await browser.close();}
