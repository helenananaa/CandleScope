from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path.cwd();out=Path(__file__).parent; b=out.parent; native=out/'native'
sys.path.insert(0,str(root/'docs/qa/alerts-main266-native-20261106'))
from app_copy import clone_app
prior=b/'alerts-main266-native-resumed-close-20261107/native/source-package-manifest.json'
m=json.loads(prior.read_text());original=Path(m['app']).resolve(strict=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
changed=subprocess.check_output(['git','diff','--name-only',m['sourceCommit'],commit,'--','backend/app','packages','frontend'],text=True).splitlines()
assert changed==['backend/app/api/v1/indicator_range_batch.py','backend/app/api/v1/stream_indicator_payloads.py','backend/app/indicator/errors.py','backend/app/indicator/history_worker.py','backend/app/indicator/range_projection.py'],changed
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
for name,h in m['files'].items():
    if name not in changed:assert sha(root/name)==h,name
subprocess.run(['codesign','--verify','--deep','--strict',str(original)],check=True)
app=native/'Installed App/CandleScope.app';clone_app(original,app)
res=app/'Contents/Resources'
for name in changed:
    target=res/name;assert not target.is_symlink() and target.resolve()==target
    shutil.copy2(root/name,target);m['files'][name]=sha(target)
subprocess.run([str(res/'python-runtime/python/bin/python3.12'),'-m','compileall','-q','-f',*[str(res/name) for name in changed]],check=True)
subprocess.run(['codesign','--force','--deep','--sign','-',str(app)],check=True)
assert sha(res/'app.asar')==m['asarSha256']
assert all(sha(res/name)==expected for name,expected in m['plugins'].items())
m.update(app=str(app),runtimeSource=str(original),sourceCommit=commit,assembly='Physical clone of prior alert candidate, with five #267 backend files overlaid and compiled. Frontend ASAR, SDK, and Pine plugin inherited by exact hashes.')
(native/'source-package-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
